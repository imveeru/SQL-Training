INSERT INTO courseInstructors VALUES
("INS005","Joe",5,3405,3,"ins005@deepsphereai.com"),
("INS006","Jadvoe",4,3405,1,"ins006@deepsphereai.com"),
("INS007","Jfaoe",4,3405,4,"ins007@deepsphereai.com"),
("INS008","Jaoe",3,3405,4,"ins008@deepsphereai.com"),
("INS009","Jgeroe",5,3405,3,"ins009@deepsphereai.com"),
("INS010","Jasoe",3,3405,4,"ins010@deepsphereai.com"),
("INS011","Josdfe",1,3405,3,"ins011@deepsphereai.com");
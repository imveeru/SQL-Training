CREATE TABLE IF NOT EXISTS students(
	StudentID int,
	FirstName varchar(255),
	LastName varchar(255),
	Age int,
	EnrollmentYear varchar(255),
	DepartmentName varchar(255),
	Semester int,
	TotalFees int,
	NoDue enum("yes","no"),
	DueAmount int
);
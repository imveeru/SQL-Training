CREATE TABLE IF NOT EXISTS Grades(
	GradeID int,
	StudentID int,
	CourseID varchar(255),
	Grade char(1)
);
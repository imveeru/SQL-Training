INSERT INTO students (name, enrolled_course) VALUES 
("AAA", 2),
("MMM", 3),
("AgreAA", 5),
("AfgdAA", 4),
("AadsfAA", 2),
("AAwaA", 10),
("AweAA", 2),
("AAasadA", 10),
("AAXX", 4);
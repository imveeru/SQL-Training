INSERT INTO DepartmentMaster (departmentName) VALUES
("CSE"),
("EEE");
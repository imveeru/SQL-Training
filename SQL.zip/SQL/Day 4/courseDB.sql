CREATE TABLE IF NOT EXISTS courses(
	course_id 	int NOT NULL,
	name		varchar(255),
	PRIMARY KEY (course_id)
);
CREATE TABLE IF NOT EXISTS DepartmentMaster(
	departmentID 	int PRIMARY KEY AUTO_INCREMENT,
	departmentName 	varchar(30) NOT NULL
);
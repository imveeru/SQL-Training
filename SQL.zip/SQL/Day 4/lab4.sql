INSERT INTO CourseMaster (CourseName) VALUES
("Python"),
("OOPS"),
("DSA"),
("Algorithm Design"),
("C Programming");
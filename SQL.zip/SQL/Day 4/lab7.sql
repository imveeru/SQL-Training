ALTER TABLE CourseInstructors ADD COLUMN DepartmentID int;
ALTER TABLE CourseInstructors ADD CONSTRAINT FOREIGN KEY(DepartmentID) REFERENCES DepartmentMaster(departmentID) ON DELETE CASCADE;
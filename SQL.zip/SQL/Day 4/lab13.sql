UPDATE CourseInstructors
SET EmailId=concat(lower(InstructorID),"@deepsphereai.com");
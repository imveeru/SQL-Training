CREATE TABLE IF NOT EXISTS CourseInstructors(
	InstructorID varchar(20),
	InstructorName varchar(30) NOT NULL,
	CourseID int,
	DepartmentName varchar(255),
	Salary int,
	FOREIGN KEY(CourseID) REFERENCES CourseMaster(CourseID)
);
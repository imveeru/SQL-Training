INSERT INTO CourseInstructors VALUES
("INS001","Max",2,2000,1),
("INS002","Rajiv",1,2000,1),
("INS003","Kathy",5,2000,2),
("INS004","Matilda",3,2000,1),
("INS005","Madhavi",4,2000,2);
CREATE TABLE IF NOT EXISTS students(
	roll_num 	int NOT NULL,
	name 		varchar(255),
	enrolled_course	int,
	PRIMARY KEY (roll_num)
);
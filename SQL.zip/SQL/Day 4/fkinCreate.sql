CREATE TABLE blah(
	id	 int NOT NULL AUTO_INCREMENT,
	name 	 varchar(56),
	class_id int,
	PRIMARY KEY(id),
	FOREIGN KEY(class_id) REFERENCES classes(id) ON UPDATE CASCADE ON DELETE CASCADE
);
SELECT 
CASE 
WHEN QUARTER(sale_date) IN (1,2) THEN "FirstHalf"
WHEN QUARTER(sale_date) IN (3,4) THEN "SecondHalf"
END AS "Half",
sum(quantity*unit_price) as Total, 
avg(quantity*unit_price) as Average,
count(quantity*unit_price) as Count 
FROM salesdata 
GROUP BY Half;
INSERT INTO subjects VALUES
(1,"DSA"),
(2,"Program Reasoning"),
(3,"Digital Electronics");
SELECT a.Region,a.MaxQ,b.product_id FROM (SELECT a.customer_region as Region,max(a.quantities) as MaxQ FROM (SELECT customer_region,product_id,sum(quantity) as quantities, sum(quantity*unit_price) as Revenue FROM salesdata GROUP BY customer_region,product_id ORDER BY customer_region, quantities DESC) a GROUP BY Region ORDER BY Region) b INNER JOIN a ON b.MaxQ=a.MaxQ;



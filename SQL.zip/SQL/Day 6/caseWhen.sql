UPDATE marks
SET grade= CASE
WHEN mark>=90 THEN "O"
WHEN mark<90 AND mark>=80 THEN "A"
WHEN mark<80 AND mark>=70 THEN "B"
WHEN mark<70 AND mark>=60 THEN "C"
WHEN mark<60 AND mark>=50 THEN "D"
ELSE "F"
END;
SELECT deptId,deptName FROM newDepts WHERE 
	(SELECT sum(salary) as Sum FROM newEmp WHERE department=deptId)>(SELECT avg(salary) FROM newEmp);

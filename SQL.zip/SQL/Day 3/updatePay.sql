UPDATE employees SET pay=20000 WHERE emp_id=1;
UPDATE employees SET pay=40000 WHERE emp_id=2;
UPDATE employees SET pay=30000 WHERE emp_id=3;
UPDATE employees SET pay=60000 WHERE emp_id=4;
UPDATE employees SET pay=10000 WHERE emp_id=5;
UPDATE employees SET pay=80000 WHERE emp_id=6;
UPDATE employees SET pay=40000 WHERE emp_id=7;
UPDATE employees SET pay=12000 WHERE emp_id=8;
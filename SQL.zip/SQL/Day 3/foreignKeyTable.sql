CREATE TABLE empPay(
	id 	int PRIMARY KEY NOT NULL AUTO_INCREMENT,
	pay 	int,
	emp_id 	int,
	FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE 
);
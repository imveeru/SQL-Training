INSERT INTO employees VALUES
(NULL,"Maxwell","2010-10-04","M",0),
(NULL,"Katie","2011-11-12","F",0),
(NULL,"Brad","2019-12-09","M",1),
(NULL,"Ada","2013-09-05","F",0),
(NULL,"Matilda","2011-01-04","F",1),
(NULL,"Lee","2017-02-14","F",1),
(NULL,"Shaun","2019-07-22","M",0),
(NULL,"Glenn","2018-08-24","M",1);
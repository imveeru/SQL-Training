CREATE TABLE IF NOT EXISTS employees(
	emp_id		int PRIMARY KEY NOT NULL AUTO_INCREMENT,
	name		varchar(128),
	doj		date,
	gender		enum("M","F","P"),
	isWFH		bool	
);
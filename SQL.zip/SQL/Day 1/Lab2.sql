create table students(
	studentID int,
    name varchar(255),
    age int,
    department varchar(255),
    grade char
);

desc students;

insert into students values(101, "Suresh", 19, "B.Sc",'A');
select * from students;
-- choosing DB
use testdb;

-- creating a table
create table students (
roll_num int,
student_name varchar(200),
city varchar(200)
); 

show tables;
use students;
select * from students;
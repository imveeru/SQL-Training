create table courses (
courseID int,
courseName varchar(255),
dept varchar(3)
);

select * from courses;

alter table courses add credits int;

desc courses;

rename table courses to courseCatalog;

show tables;

desc courseCatalog;

drop table courseCatalog;

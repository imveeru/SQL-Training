-- select all
SELECT * FROM students;

-- select students from London
SELECT student_name from students where city="London";

-- 
-- Day 1 
-- Basic SQL commands

-- absolute number
select abs(100) as absolute;

-- modulus
select mod(10,4) as remainder;

-- max and min in series
select greatest(2,1,4,234,2,121) as greatest;
select least(13.23,2,23,24,24,23) as least;

-- truncate decimals
select truncate(12.80959,1) as truncated;

-- round off
select round(12.8904390,2) as roundoff; 

-- math operation
select 12+2 as sum;

-- string case
select upper("hellO") as upper;
select lower("HelLO") as lower;

-- string length
select char_length("Hellooo") as len;

-- string concatenation
select concat_ws(" ","Sachin","Tendulkar") as concat;
select concat("Hello ","World") as concat_1;

-- string replace
select replace("Virat Kohli", "Vi", "Why") as replacestr;

-- trim string
select ltrim("                          hello           ") as ltrimstr;
select length(ltrim("                          hello           ")) as ltrim_len;
select length(rtrim("                          hello           ")) as rtrim_len;
select length(trim("                          hello           ")) as trim_len;

-- string slicing
select left("asdfghjkl",5) as first5;
select right("asdfghjkl",5) as last5;

-- get today's date
select sysdate() as today;

-- string reversal
select reverse("hello") as revstr;

-- palindrome
select "hello"=reverse("hello") as palindrome;
select "malayalam"=reverse("malayalam") as palindrome;

-- select active user
select user() as username;

-- odd or even
select if(mod(6,2)=0,"even","odd") as if_else;

-- like (contains that string [regexp])
select "apple" LIKE "%a%" or "apple" LIKE "%e%" or "apple" LIKE "%i%" or "apple" LIKE "%o%" or "apple" LIKE "%u%" as hasVowels;

-- ifelse with multiple conditions
select if((length("hi")<5) AND ("hi" LIKE "%e%"),"Yes","No") as ifelse_with_and;
select if((length("hi")<5) OR ("hi" LIKE "%e%"),"Yes","No") as ifelse_with_or;

-- check range
select if(21 between 20 and 40,"Yes","No") as check_range;
select if(1 between 20 and 40,"Yes","No") as check_range;

-- check in list
select if(1 in(1,2,4,5,9), "Yes", "No") as check_list;
select if(1000 in(1,2,4,5,9), "Yes", "No") as check_list;
select if(1 not in(1,2,4,5,9), "Yes", "No") as check_list;
select if(14 not in(1,2,4,5,9), "Yes", "No") as check_list;


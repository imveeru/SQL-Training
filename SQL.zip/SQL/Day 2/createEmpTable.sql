CREATE TABLE IF NOT EXISTS employees(
	empID 	int NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name	varchar(255),
	dept	char(3),
	gender 	enum("M","F","O"),
	dob	date,
	isOnsite bool
);
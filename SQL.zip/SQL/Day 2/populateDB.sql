INSERT INTO employees (name,dept,gender,dob,isOnsite) VALUES
("Amar","CSE","M","1989-07-13",0),
("Aisha","ECE","F","1999-02-16",1),
("Shah","EEE","M","1992-01-14",0),
("Ajay","CSE","M","1984-12-03",1),
("Zen","MEE","M","1981-07-12",0),
("Kajal","EEE","F","1992-08-11",0),
("Rukh","CSE","M","1981-03-22",1),
("Amy","ECE","F","1990-10-23",0),
("Priya","MEE","F","1984-09-13",1),
("Akbar","CSE","M","1989-11-12",1);
-- Select all
SELECT * FROM employees;
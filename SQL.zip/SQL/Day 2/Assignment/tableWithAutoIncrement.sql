CREATE TABLE IF NOT EXISTS students(
	id 		int NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name		varchar(255),
	dept	char(3)
);

INSERT INTO students VALUES
	(NULL, "Maxwell", "CSE"),
	(NULL, "Watson", "EEE");
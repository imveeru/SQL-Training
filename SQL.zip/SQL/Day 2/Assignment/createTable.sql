CREATE TABLE IF NOT EXISTS newEmployees(
	empID 	int NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name	varchar(255),
	dob	date
);
CREATE TABLE IF NOT EXISTS city_details(
	id 		int NOT NULL PRIMARY KEY AUTO_INCREMENT,
	city_name	varchar(255),
	avg_temp	int 
);
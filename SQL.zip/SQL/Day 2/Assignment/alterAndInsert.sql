ALTER TABLE newEmployees ADD COLUMN gender enum("M","F");
INSERT INTO newEmployees VALUES (NULL, "Max","2023-05-14","M");